import { Airport } from './airport';

describe('Airport', () => {
  it('should create an instance', () => {
    expect(new Airport()).toBeTruthy();
  });
});
