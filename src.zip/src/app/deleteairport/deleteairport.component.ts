import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-deleteairport',
  templateUrl: './deleteairport.component.html',
  styleUrls: ['./deleteairport.component.css']
})
export class DeleteairportComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
