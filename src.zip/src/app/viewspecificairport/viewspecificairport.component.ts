import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewspecificairport',
  templateUrl: './viewspecificairport.component.html',
  styleUrls: ['./viewspecificairport.component.css']
})
export class ViewspecificairportComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
