import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewspecificairportComponent } from './viewspecificairport.component';

describe('ViewspecificairportComponent', () => {
  let component: ViewspecificairportComponent;
  let fixture: ComponentFixture<ViewspecificairportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewspecificairportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewspecificairportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
