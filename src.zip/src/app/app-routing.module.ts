import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddairportComponent } from './addairport/addairport.component';
import { ModifyairportComponent } from './modifyairport/modifyairport.component';
import { ViewspecificairportComponent } from './viewspecificairport/viewspecificairport.component';
import { DeleteairportComponent } from './deleteairport/deleteairport.component';
import { ViewairportComponent } from './viewairport/viewairport.component';


const routes: Routes = [
  {path:'viewairport',component:ViewairportComponent},
  {path:'deleteairport',component:DeleteairportComponent},
  {path:'modifyairport',component:ModifyairportComponent},
  {path:'viewspecificairport',component:ViewspecificairportComponent},
  {path:'addairport',component:AddairportComponent},



];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
