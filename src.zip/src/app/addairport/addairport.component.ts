import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addairport',
  templateUrl: './addairport.component.html',
  styleUrls: ['./addairport.component.css']
})
export class AddairportComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
