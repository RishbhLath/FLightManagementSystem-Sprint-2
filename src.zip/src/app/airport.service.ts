import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Airport } from './airport';

@Injectable({
  providedIn: 'root'
})
export class AirportService {

  airport:Airport[]=[];
 
  constructor(private http:HttpClient) {}
  
  public viewAirport():Observable<any>
  {
    let url="http://localhost:1131/airport/viewAirport";
 
    return this.http.get(url);
  }}
