import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ModifyairportComponent } from './modifyairport.component';

describe('ModifyairportComponent', () => {
  let component: ModifyairportComponent;
  let fixture: ComponentFixture<ModifyairportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ModifyairportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ModifyairportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
