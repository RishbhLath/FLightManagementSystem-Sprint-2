import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-modifyairport',
  templateUrl: './modifyairport.component.html',
  styleUrls: ['./modifyairport.component.css']
})
export class ModifyairportComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
