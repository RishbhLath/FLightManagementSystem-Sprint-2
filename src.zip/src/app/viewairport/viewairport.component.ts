import { Component, OnInit } from '@angular/core';
import { AirportService } from '../airport.service';
import { Airport } from '../airport';

@Component({
  selector: 'app-viewairport',
  templateUrl: './viewairport.component.html',
  styleUrls: ['./viewairport.component.css']
})
export class ViewairportComponent implements OnInit {

  constructor(private service:AirportService) { }

 airport:Airport[]=[];

 ngOnInit(): void {
      
    this.service.viewAirport().subscribe(data=>
      {
        this.airport=data;
      },
      error=>
      {
        console.log("erroor occured",error);
      }
      );
    
  }
  

}
