import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { AddairportComponent } from './addairport/addairport.component';
import { DeleteairportComponent } from './deleteairport/deleteairport.component';
import { ModifyairportComponent } from './modifyairport/modifyairport.component';
import { ViewairportComponent } from './viewairport/viewairport.component';
import { ViewspecificairportComponent } from './viewspecificairport/viewspecificairport.component';

@NgModule({
  declarations: [
    AppComponent,
    AddairportComponent,
    DeleteairportComponent,
    ModifyairportComponent,
    ViewairportComponent,
    ViewspecificairportComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
    
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
